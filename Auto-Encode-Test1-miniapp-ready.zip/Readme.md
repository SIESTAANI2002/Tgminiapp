[![Deploy](https://www.herokucdn.com/deploy/button.svg)](https://www.heroku.com/deploy?template=https://github.com/SIESTAANI2002/Auto-Encode-Test1)

## Features

- Automatic upload of anime files to a Telegram channel.
- Support for multiple file resolutions: 480p, 720p, and 1080p.
- Encoding of 720p files.
- User-friendly interface for accessing uploaded files from Bot.
